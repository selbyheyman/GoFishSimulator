
/**
 * Write a description of class EmptyDeckException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EmptyDeckException extends Exception {
    /**
     * Constructor for objects of class EmptyDeckException
     */
    public EmptyDeckException(String m)
    {
        super(m);
    }
}