import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;
/**
 * Write a description of class Card here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hand
{
    // instance variables
    private ArrayList<String> hand;
    private Random rng = new Random();

    /**
     * Constructor for objects of class Hand
     */
    public Hand() {
        // creates a hand object with empty String ArrayList
        this.hand = new ArrayList<String>();
    }
    

    /**
     * Creates a hand of 7 random cards from the deck, removing them from the
     * deck in the process.
     *
     * @param  d  the deck object created in the main method
     */
    public void dealHand(Deck d)
    {
        for (int i=0; i<7; i++) {
            int index = rng.nextInt(d.size());
            String card = d.get(index);
            this.hand.add(card);
            d.remove(index);
        }
    }

    /**
     * Returns the number of cards in the hand.
     * 
     * @return    number of cards in the hand
     */
    public int size() {
        return this.hand.size();
    }
    
    /**
     * Returns the card of the specified index from the hand.
     * 
     * @param  x  index of the card to be retrieved
     * @return    the card of index x from the hand
     */
    public String get(int n) {
        return this.hand.get(n);
    }
    
    /**
     * Adds a card to the hand.
     */
    public void add(String c) {
        this.hand.add(c);
    }
    
    /**
     * Prints each card in the hand.
     */
    public void printHand() {
        System.out.println("The cards in your hand are: ");
        for (int i=0; i<this.hand.size()-1; i++) {
            System.out.print(this.hand.get(i) + ", ");
        }
        System.out.print(this.hand.get(this.hand.size()-1));
        System.out.println();
    }
    
    /**
     * Searches for the asked card in the other player's hand and removes it, 
     * returning the number of that card to be added to the asker's hand.
     * 
     * @param  c  the card being asked for
     * @return    number of cards gained by the asker
     */
    public int getAskCard(String c) {
        int count=0;
        for (int i=0; i<this.hand.size(); i++) {
            String x = this.hand.get(i);
            if (x.equals(c)) {
                this.hand.remove(i);
                count=count+1;
            }
        }
        return count;
    }
    
    /**
     * Counts the number of a specific type of card in the hand.
     * 
     * @param  c  type of card you want to count
     * @return    number of cards c in the hand
     */
    public int countCard(String c) {
        int count=0;
        for (int i=0; i<this.hand.size(); i++) {
            if (this.hand.get(i).equals(c)) {
                count+=1;
            }
        }
        return count;
    }
    
    /**
     * Counts the number of a specific type of card in the hand.
     * 
     * @param  c  type of card you want to count
     * @return    number of cards c in the hand
     */
    public boolean containsCard(String c) {
        for (int i=0; i<this.hand.size(); i++) {
            if (this.hand.get(i).equals(c)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Adds a specified number of a specified card to the hand.
     * 
     * @param  c  type of card being added to the hand
     * @param  n  number of that card being added
     */
    public void addCard(String c, int n) {
        for (int i=0; i<n; i++) {
            this.hand.add(c);
        }
    }
    
    /**
     * Checks if there are any books in the hand and removes them,
     * returning the card that was removed.
     * 
     * @return    type of card that was made into a book and removed
     */
    public String anyBooks() {
        String c=null;
        for (int i=0; i<this.hand.size(); i++) {
            c = this.hand.get(i);
            int numC = Collections.frequency(this.hand, c);
            if (numC>=4) {
                this.hand.removeAll(Collections.singleton(c));
                return c;
            }
        }
        return null;
    }
}
