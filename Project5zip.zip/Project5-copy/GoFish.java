import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Math;

/**
 * Write a description of class GoFish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class GoFish {
    public static void main(String args[]) {
        //creates Scanner object
        Scanner sc = new Scanner(System.in);
        
        // creates the deck, user's hand, and computer's hand for the game
        Deck deck = new Deck();
        Hand userHand = new Hand();
        Hand cpuHand = new Hand();
        
        // shuffles the deck and deals to user and computer
        deck.shuffle();
        userHand.dealHand(deck);
        cpuHand.dealHand(deck);
        
        // prints welcome messge and rules to the user
        // user presses enter to continue
        System.out.println("=======================================");
        System.out.println("Welcome to the Go Fish game simulator!");
        System.out.println("=======================================");
        promptEnter();
        
        System.out.println("Here are the rules:");
        System.out.println("You will be playing against CPU, our computer friend. The");
        System.out.println("goal of the game is to get as many 'books' (four of a kind)");
        System.out.println("as you can!");
        System.out.println();
        System.out.println("To start, both you and CPU will be dealt 7 cards from the");
        System.out.println("deck and the rest of the cards will be put into the draw");
        System.out.println("pile. You can only see the cards in your own hand.");
        System.out.println();
        System.out.println("When it's your turn, you will ask CPU for any card, and if"); 
        System.out.println("they have it in their hand, they will give it to you.");
        System.out.println("You'll want to ask for a card you already have in your hand,");
        System.out.println("unless you want to try to trick CPU... :-)");
        System.out.println();
        System.out.println("If CPU does not have the card you asked for, you'll 'go fish'");
        System.out.println("and take a card from the draw pile, and your turn will end.");
        System.out.println("Then, CPU will do the same, and the game will continue until");
        System.out.println("someone runs out of cards and there are no cards left in the");
        System.out.println("draw pile. Whoever has the most books at the end wins!");
        promptEnter();
        
        System.out.println(" **IMPORTANT GAME PLAY NOTICE** ");
        System.out.println("When prompted to input the card you want to ask CPU for, you");
        System.out.println("must type one of these symbols, which represents each type");
        System.out.println("of card: 'A' for Ace, 'K' for King, 'Q' for Queen,");
        System.out.println("'J' for Jack, and numbers 2-10.");
        System.out.println("The suits of the cards don't matter in this game, so this");
        System.out.println("is the only typing rule you have to worry about.");
        System.out.println();
        System.out.println("Also, before each turn, the program will display the cards,");
        System.out.println("in your hand, as well as the cards that are still 'in play',");
        System.out.println("meaning those which have not yet been made in to books.");
        System.out.println("Now you're ready to play!");
        promptEnter();
        
        System.out.println("Dealing cards and shuffling deck . . .");
        promptEnter();
        
        // initializes count of total books of each player, this determines who wins the game
        int userBooks=0;
        int cpuBooks=0;
        
        // stores the cards the user asks for, so that CPU can ask for the card the 
        // user asked for last at the start of their next turn
        ArrayList<String> userAsk = new ArrayList<>();
        
        // keeps track of the cards still in play (have not been made into books)
        ArrayList<String> playCards = new ArrayList<>();
        playCards.add("A");
        playCards.add("2");
        playCards.add("3");
        playCards.add("4");
        playCards.add("5");
        playCards.add("6");
        playCards.add("7");
        playCards.add("8");
        playCards.add("9");
        playCards.add("10");
        playCards.add("J");
        playCards.add("Q");
        playCards.add("K");
        
        // game play takes place here
        // while cpu and user both have more than zero cards, and there are cards in the deck
        while (cpuHand.size()>0 && userHand.size()>0 && deck.size()>0) {
            // user's turn
            boolean userTurn=true;
            while (userTurn==true) {
                System.out.println("It's your turn!");
                // counting books in the user's hand and printing a message 
                String p = userHand.anyBooks();
                if (p!=null) {
                    userBooks+=1;
                    System.out.println("You have four "+ p + "s! You now have " + userBooks + " book(s) total.");
                    if (userBooks>cpuBooks) {
                        System.out.println("CPU has " + cpuBooks + " book(s). You're in the lead!");
                    } else if (userBooks==cpuBooks) {
                        System.out.println("CPU has " + cpuBooks + " book(s). You're tied!");
                    } else if (userBooks<cpuBooks) {
                        System.out.println("CPU has " + cpuBooks + " book(s). CPU is in the lead!");
                    }
                    promptEnter();
                    
                    // removing the card that was made into a book from the playable cards
                    playCards.remove(p);
                }
                
                
                // prints the cards still in play
                if (playCards.size()>1) {
                    System.out.println("These are the cards in play: ");
                        for (int r=0; r<playCards.size()-1; r++) {
                            System.out.print(playCards.get(r) + ", ");
                        }
                    System.out.print(playCards.get(playCards.size()-1));
                }
                System.out.println();
                if (userHand.size()>1) {
                    userHand.printHand();
                }
                
                // asks the user to input the card they want to ask CPU for
                System.out.println("Type the card you want to ask CPU for: ");
                String askCard = sc.nextLine();
                boolean valid = checkValidAsk(playCards, askCard);
                while (valid==false) {
                    System.out.println("That is not a valid input!");
                    System.out.println("Type the card you want to ask CPU for: ");
                    askCard = sc.nextLine();
                    valid = checkValidAsk(playCards, askCard);
                }
                System.out.println();
                
                //adds the card asked for to the arraylist
                userAsk.add(askCard);
                
                // checking CPU's hand for the card asked for
                boolean win = cpuHand.containsCard(askCard);
                if (win) {
                    int y = cpuHand.getAskCard(askCard);
                    System.out.println("CPU gives you " + y + " " + askCard + "(s)!");
                    userHand.addCard(askCard, y);
                    
                    // counting books in the user's hand and printing a message 
                    String w = userHand.anyBooks();
                    if (w!=null) {
                        userBooks+=1;
                        System.out.println("You have four " + w + "s! You now have " + userBooks + " book(s) total.");
                        if (userBooks>cpuBooks) {
                            System.out.println("CPU has " + cpuBooks + " book(s). You're in the lead!");
                        } else if (userBooks==cpuBooks) {
                            System.out.println("CPU has " + cpuBooks + " book(s). You're tied!");
                        } else if (userBooks<cpuBooks) {
                            System.out.println("CPU has " + cpuBooks + " book(s). CPU is in the lead!");
                        }
                        promptEnter();
                        
                        // removing the card that was made into a book from the playable cards
                        playCards.remove(w);
                    }
                } else if (!win) {
                    System.out.println("CPU does not have any " + askCard + "s. Go Fish!");
                    try {
                        String drawCard=deck.draw();
                        System.out.println("You draw a "+drawCard);
                        userHand.addCard(drawCard, 1);
                    } catch (EmptyDeckException e) {
                        System.err.println("EmptyDeckException: " + e.getMessage());
                    }
                    userTurn=false;
                }
            }
            
            promptEnter();
            
            //CPU's turn
            boolean cpuTurn=true;
            while (cpuTurn==true) {
                System.out.println("It's CPU's turn!");
                
                // count to ensure the computer only asks for the card last asked for once
                int once=0;
                String askCard="";
                String lastAsk = userAsk.get(userAsk.size()-1);
                if (cpuHand.size()>1) {
                    if (cpuHand.containsCard(lastAsk) && once<1) {
                        askCard = userAsk.get(userAsk.size()-1);
                    } else {
                        // gets a random card from the cpu's hand
                        int z = random(0, cpuHand.size()-1);
                        askCard = cpuHand.get(z);
                    }
                } else if (cpuHand.size()==0) {
                    System.out.println("CPU has no cards, so they draw from the deck.");
                    promptEnter();
                    try {
                        String newCard = deck.draw();
                        cpuHand.add(newCard);
                        askCard = newCard;
                    } catch (EmptyDeckException e) {
                        System.err.println("EmptyDeckException: " + e.getMessage());
                        System.out.println("There are no more cards in the deck.");
                        cpuTurn = false;
                    }
                }
                
                once+=1;
                
                System.out.println("CPU asks you for all your " + askCard + "s.");
                
                // checking user's hand for the card asked for
                boolean win = userHand.containsCard(askCard);
                if (win) {
                    int y = userHand.getAskCard(askCard);
                    System.out.println("You give CPU " + y + " " + askCard + "(s)!");
                    cpuHand.addCard(askCard, y);
                    promptEnter();
                    
                    // counting books in the cpu's hand and printing a message 
                    String x = cpuHand.anyBooks();
                    if (x!=null) {
                        cpuBooks+=1;
                        System.out.println("CPU has four of a kind! CPU now has " + cpuBooks + " book(s) total.");
                        if (userBooks>cpuBooks) {
                            System.out.println("You have " + userBooks + " book(s). You're still in the lead!");
                        } else if (userBooks==cpuBooks) {
                            System.out.println("You have " + userBooks + " book(s). You're now tied!");
                        } else if (userBooks<cpuBooks) {
                            System.out.println("You have " + userBooks + " book(s). CPU is in the lead!");
                        }
                        promptEnter();
                        
                        // removing the card that was made into a book from the playable cards
                        playCards.remove(x);
                    }
                } else if (!win) {
                    System.out.println("You don't have any " + askCard + "s. CPU, Go Fish!");
                    try {
                        String drawCard=deck.draw();
                        cpuHand.addCard(drawCard, 1);
                    } catch (EmptyDeckException e) {
                        System.err.println("EmptyDeckException: " + e.getMessage());
                    }
                    promptEnter();
                    cpuTurn=false;
                }
            }
        }
        
        // will run when either player runs out of cards and there are no cards in the deck
        System.out.println("===========");
        System.out.println("Game over!");
        System.out.println("===========");
        System.out.println();
        if (userBooks>cpuBooks) {
            System.out.println("You have " + userBooks + " book(s).");
            System.out.println("CPU has " + cpuBooks + " book(s).");
            System.out.println("You win!");
        } else if (userBooks==cpuBooks) {
            System.out.println("You have " + userBooks + " book(s).");
            System.out.println("CPU has " + cpuBooks + " book(s).");
            System.out.println("You and CPU tied!");
        } else if (userBooks<cpuBooks) {
            System.out.println("You have " + userBooks + " book(s).");
            System.out.println("CPU has " + cpuBooks + " book(s).");
            System.out.println("CPU wins!");
        }
    }
    
    public static void promptEnter() {
        System.out.println("Press \"ENTER\" to continue...");
        Scanner sc = new Scanner(System.in);
        sc.nextLine();
    }
    
    public static boolean checkValidAsk(ArrayList<String> p, String a) {
        for (int b=0; b<p.size(); b++) {
            if (p.get(b).equals(a)) {
                return true;
            }
        }
        return false;
    }
    
    public static int random(int x, int y) {
        double rand = Math.random();
        int num = (int)rand;
        return num * (x - y) + y;
    }
}
    
