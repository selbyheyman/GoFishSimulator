import java.util.ArrayList;
import java.util.Random;
/**
 * Write a description of class Deck here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Deck
{
    // instance variables - replace the example below with your own
    private ArrayList<String> deck;
    private Random rng;

    /**
     * Constructor for objects of class Deck
     */
    public Deck() {
        // initialises instance variable
        this.deck = new ArrayList<String>();
        // adds four of each kind of card to the new unshuffled deck
        for (int i=0; i<4; i++) {
            this.deck.add("A");
            this.deck.add("2");
            this.deck.add("3");
            this.deck.add("4");
            this.deck.add("5");
            this.deck.add("6");
            this.deck.add("7");
            this.deck.add("8");
            this.deck.add("9");
            this.deck.add("10");
            this.deck.add("J");
            this.deck.add("Q");
            this.deck.add("K");
        }
    }

    /**
     * Switches the indexes of two random cards within the deck 250 times 
     * to give each card within the deck a decent chance to be shuffled.
     */
    public void shuffle()
    {
        for (int i=0; i<250; i++) {
            rng = new Random();
            int x = rng.nextInt(this.deck.size());
            int y = rng.nextInt(this.deck.size());
            while (x<0) {
                x = x+50;
            }
            while (y<0) {
                y = y+50;
            }
            String hold = this.deck.get(x);
            this.deck.set(x,this.deck.get(y));
            this.deck.set(y,hold);
        }
    }
    
    /**
     * Counts how many elements (cards) are in the deck
     *
     * @return    the the number of cards in the deck
     */
    public int size()
    {
        return this.deck.size();
    }
    
    /**
     * Retrieves the card from the specified index from the deck
     *
     * @param  x   the index of the card to be retrieved
     * @return     the card from index x
     */
    public String get(int x)
    {
        return this.deck.get(x);
    }
    
    /**
     * removes the card from the specified index
     *
     * @param  x  a sample parameter for a method
     */
    public void remove(int x)
    {
        this.deck.remove(x);
    }
    
    /**
     * Prints each card in the hand. (For testing purposes).
     */
    public void printDeck() {
        for (int i=0; i<this.deck.size()-1; i++) {
            System.out.print(this.deck.get(i) + ", ");
        }
        System.out.print(this.deck.get(this.deck.size()-1));
    }
    
    /**
     * Draws a card from the beginning of the deck.
     * 
     * Throws EmptyDeckException if the deck size is 0.
     * 
     * @return    card from index 0 of the deck
     */
    public String draw() throws EmptyDeckException {
        if (this.deck.size() == 0) {
            throw new EmptyDeckException("The deck is empty. No card is drawn.");
        }
        String drawCard = this.deck.get(0);
        this.deck.remove(0);
        return drawCard;
    }
}
